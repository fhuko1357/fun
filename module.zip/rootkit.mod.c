#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(.gnu.linkonce.this_module) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section(__versions) = {
	{ 0xc2b78c96, "module_layout" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xd1fbc889, "unregister_kprobe" },
	{ 0x8ee53e31, "register_kprobe" },
	{ 0x20000329, "simple_strtoul" },
	{ 0x999e8297, "vfree" },
	{ 0x4e58432e, "pv_ops" },
	{ 0xb44ad4b3, "_copy_to_user" },
	{ 0xfb578fc5, "memset" },
	{ 0x362586da, "current_task" },
	{ 0xc5850110, "printk" },
	{ 0xe007de41, "kallsyms_lookup_name" },
	{ 0xcb970751, "stop_machine" },
	{ 0xacc11194, "init_task" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0xb7a660c1, "wake_up_process" },
	{ 0xcc5005fe, "msleep_interruptible" },
	{ 0x37a0cba, "kfree" },
	{ 0x69acdf38, "memcpy" },
	{ 0xe045ecd6, "param_ops_long" },
	{ 0xb0e602eb, "memmove" },
	{ 0xe3fffae9, "__x86_indirect_thunk_rbp" },
	{ 0x362ef408, "_copy_from_user" },
	{ 0x88db9f48, "__check_object_size" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "32A6C5C8C4E62435875DA3E");
