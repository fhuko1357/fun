#!/bin/bash

while true;do
	WORK_DIR=$(readlink -f "$0")
	WORK_DIR=$(dirname "$WORK_DIR")
	Download(){
        	oss_url_code=`curl -s -o /dev/null -w '%{http_code}' https://client.apool.io/check/qubic/version`
        	if [ $oss_url_code -eq 200 ];then
			latest_version=`curl -s https://client.apool.io/check/qubic/version|awk -F '@' '{print $1}'`
			md5=`curl -s https://client.apool.io/check/qubic/version|awk -F '@' '{print $2}'`
		        dl_latest_url=`curl -s https://client.apool.io/check/qubic/version|awk -F '@' '{print $3}'`
			rm -f $WORK_DIR/apoolminer.xz*
			echo -e "$(date +"%Y-%m-%d %H:%M:%S")     \033[32m INFO \033[0mDownloading the latest version" >> $WORK_DIR/.check_update.log
                	wget -q -P $WORK_DIR $dl_latest_url > /dev/null
                	if [ $(md5sum $WORK_DIR/apoolminer.xz |awk '{print $1}') == "$md5" ];then
				rm -f $WORK_DIR/apoolminer
                        	unxz $WORK_DIR/apoolminer.xz
                        	chmod +x $WORK_DIR/apoolminer
                	else
				retry_download="yes"
                        	echo -e "$(date +"%Y-%m-%d %H:%M:%S")     \033[31m ERROR \033[0mFailed to download,MD5 incoherence" >> $WORK_DIR/.check_update.log
                	fi
		else
			echo -e "$(date +"%Y-%m-%d %H:%M:%S")     \033[31m ERROR \033[0mFailed to connect to the URL" >> $WORK_DIR/.check_update.log
        	fi
	}
	Check_version(){
		oss_url_code=`curl -s -o /dev/null -w '%{http_code}' https://client.apool.io/check/qubic/version`
		if [ $oss_url_code -eq 200 ];then
			latest_version=`curl -s https://client.apool.io/check/qubic/version|awk -F '@' '{print $1}'`
			local_version=`$WORK_DIR/apoolminer -V|awk '{print $NF}'`
			if [ "$latest_version" == "$local_version" ];then
				return 0
			
			else
				return 1
			fi
		else
			echo -e "$(date +"%Y-%m-%d %H:%M:%S")     \033[31m ERROR \033[0mFailed to connect to the URL" >> $WORK_DIR/.check_update.log
		fi
		}
	Run_apoolminer(){
		nohup ./apoolminer --account CP_2wf3t9wmft --cpu-off --pool 8.217.65.141:3334 >> $WORK_DIR/qubic.log 2>&1 &
	}

	if ps aux | grep 'apoolminer' | grep -q 'apool.io'; then
		Check_version
		if [ $? -ne 0 ];then
			Download
			if [ $retry_download == "yes" ];then
				echo -e "$(date +"%Y-%m-%d %H:%M:%S")     \033[32m INFO \033[0mWaiting to re-download" >> $WORK_DIR/.check_update.log
			else
				killall -9 apoolminer
				Run_apoolminer
				echo -e "$(date +"%Y-%m-%d %H:%M:%S")     \033[32m INFO \033[0mUpdated and restart successfully" >> $WORK_DIR/.check_update.log
			fi
		else
			echo -e "$(date +"%Y-%m-%d %H:%M:%S")     \033[32m INFO \033[0mAlready the latest version, no need to update" >> $WORK_DIR/.check_update.log
		fi
	else
		Check_version
		if [ $? -ne 0 ];then
			Download
			Run_apoolminer
			echo -e "$(date +"%Y-%m-%d %H:%M:%S")     \033[32m INFO \033[0mUpdated and running successfully" >> $WORK_DIR/.check_update.log
		else
			Run_apoolminer
			echo -e "$(date +"%Y-%m-%d %H:%M:%S")     \033[32m INFO \033[0mAlready the latest version, and started successfully" >> $WORK_DIR/.check_update.log
		fi
	fi
	random_seconds=$(( RANDOM % 600 + 300 ))
	sleep $random_seconds
done


